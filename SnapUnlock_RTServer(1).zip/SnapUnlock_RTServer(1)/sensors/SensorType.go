/*
 * @Author: your name
 * @Date: 2020-09-02 17:02:41
 * @LastEditTime: 2020-09-03 15:28:02
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \GoProject\SnapUnlock_RTServer\util\SensorType.go
 */
package sensors

var ACCELEROMETER int = 1
var MICROPHONE int = 131073
