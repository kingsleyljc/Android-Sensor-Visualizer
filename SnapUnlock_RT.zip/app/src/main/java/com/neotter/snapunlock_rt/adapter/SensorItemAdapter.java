package com.neotter.snapunlock_rt.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.Switch;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
import java.util.Set;

import com.neotter.snapunlock_rt.R;
import com.neotter.snapunlock_rt.object.sensor.CommonSensor;

public class SensorItemAdapter extends RecyclerView.Adapter<SensorItemAdapter.SensorItemHolder> {
    public interface OnToggleSensorListener {
        void onChanged(CommonSensor sensor, boolean isChecked);
    }

    private OnToggleSensorListener listener;
    private List<CommonSensor> sensorList;
    private Set<CommonSensor> selectedSensorList;

    public SensorItemAdapter(List<CommonSensor> sensorList, Set<CommonSensor> selectedSensorList) {
        super();

        this.sensorList = sensorList;
        this.selectedSensorList = selectedSensorList;
    }

    public void setOnToggleSensorListener(OnToggleSensorListener listener) {
        this.listener = listener;
    }

    @NonNull
    @Override
    public SensorItemHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_sensor, null);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        view.setLayoutParams(lp);
        return new SensorItemHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SensorItemHolder sensorItemHolder, int i) {
        CommonSensor sensor = sensorList.get(i);
        sensorItemHolder.sensor = sensor;
        sensorItemHolder.mSwitch.setText(String.format("%s(%dHz)", sensor.getName(), sensor.getMaxRate()));
        sensorItemHolder.mSwitch.setChecked(selectedSensorList.contains(sensor));
    }

    @Override
    public int getItemCount() {
        return sensorList.size();
    }

    public class SensorItemHolder extends RecyclerView.ViewHolder implements CompoundButton.OnCheckedChangeListener {
        public Switch mSwitch;
        public CommonSensor sensor;

        public SensorItemHolder(@NonNull View itemView) {
            super(itemView);

            mSwitch = itemView.findViewById(R.id.switch1);
            mSwitch.setOnCheckedChangeListener(this);
        }

        @Override
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            if (null != listener) {
                listener.onChanged(sensor, isChecked);
            }
        }
    }
}
