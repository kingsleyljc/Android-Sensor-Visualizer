package com.neotter.snapunlock_rt.service.audio;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

/**
 * Created by HXL on 16/3/9.
 * wav文件头
 */
public class WaveHeader {
    // 区块编号
    public final char fileID[] = {'R', 'I', 'F', 'F'};
    // 总区块大小
    public int fileLength;
    // 档案格式
    public char wavTag[] = {'W', 'A', 'V', 'E'};
    // 子区块1标识
    public char FmtHdrID[] = {'f', 'm', 't', ' '};
    // 子区块1大小
    public int FmtHdrLeth;
    // 音频格式
    public short FormatTag;
    // 声道数量
    public short Channels;
    // 采样频率
    public int SamplesPerSec;
    // 位元（组）率
    public int AvgBytesPerSec;
    // 区块对齐
    public short BlockAlign;
    public short BitsPerSample;
    public char DataHdrID[] = {'d','a','t','a'};
    public int DataHdrLeth;

    public byte[] getHeader() throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        WriteChar(bos, fileID);
        WriteInt(bos, fileLength);
        WriteChar(bos, wavTag);
        WriteChar(bos, FmtHdrID);
        WriteInt(bos,FmtHdrLeth);
        WriteShort(bos,FormatTag);
        WriteShort(bos,Channels);
        WriteInt(bos,SamplesPerSec);
        WriteInt(bos,AvgBytesPerSec);
        WriteShort(bos,BlockAlign);
        WriteShort(bos,BitsPerSample);
        WriteChar(bos,DataHdrID);
        WriteInt(bos,DataHdrLeth);
        bos.flush();
        byte[] r = bos.toByteArray();
        bos.close();
        return r;
    }

    private void WriteShort(ByteArrayOutputStream bos, int s) throws IOException {
        byte[] mybyte = new byte[2];
        mybyte[1] =(byte)( (s << 16) >> 24 );
        mybyte[0] =(byte)( (s << 24) >> 24 );
        bos.write(mybyte);
    }


    private void WriteInt(ByteArrayOutputStream bos, int n) throws IOException {
        byte[] buf = new byte[4];
        buf[3] =(byte)( n >> 24 );
        buf[2] =(byte)( (n << 8) >> 24 );
        buf[1] =(byte)( (n << 16) >> 24 );
        buf[0] =(byte)( (n << 24) >> 24 );
        bos.write(buf);
    }

    private void WriteChar(ByteArrayOutputStream bos, char[] id) {
        for (int i=0; i<id.length; i++) {
            char c = id[i];
            bos.write(c);
        }
    }
}
