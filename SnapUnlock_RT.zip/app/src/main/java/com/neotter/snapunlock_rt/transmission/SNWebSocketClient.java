package com.neotter.snapunlock_rt.transmission;

import android.util.Log;

import com.neotter.snapunlock_rt.transmission.util.ByteUtil;

import okhttp3.OkHttpClient;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import okio.ByteString;

public class SNWebSocketClient extends WebSocketListener {


    @Override
    public void onOpen(WebSocket webSocket, Response response) {
        super.onOpen(webSocket, response);
        Log.i("SNWebSocketClient","onOpen");
    }

    @Override
    public void onMessage(WebSocket webSocket, String text) {
        super.onMessage(webSocket, text);
        Log.i("SNWebSocketClient","onMessageString "+text);
    }

    @Override
    public void onMessage(WebSocket webSocket, ByteString bytes) {
        super.onMessage(webSocket, bytes);
        String mg = "X: "+ByteUtil.byte2float(bytes.toByteArray(),5)
                  +" Y: "+ByteUtil.byte2float(bytes.toByteArray(),5+4)
                  +" Z: "+ByteUtil.byte2float(bytes.toByteArray(),5+4+4);
        Log.i("SNWebSocketClient","onMessageByteString "+ mg);
    }

    @Override
    public void onClosing(WebSocket webSocket, int code, String reason) {
        super.onClosing(webSocket, code, reason);
        Log.i("SNWebSocketClient","onClosing");

    }

    @Override
    public void onClosed(WebSocket webSocket, int code, String reason) {
        super.onClosed(webSocket, code, reason);
        Log.i("SNWebSocketClient","onClosed");
    }

    @Override
    public void onFailure(WebSocket webSocket, Throwable t, Response response) {
        super.onFailure(webSocket, t, response);
        Log.i("SNWebSocketClient","onFailure");
        Log.i("SNWebSocketClient","throwable:"+t.getMessage());
        Log.i("SNWebSocketClient","response:"+response.message());


    }
}
