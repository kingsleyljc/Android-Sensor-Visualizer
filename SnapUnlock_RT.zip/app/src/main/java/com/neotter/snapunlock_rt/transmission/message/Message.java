package com.neotter.snapunlock_rt.transmission.message;

public abstract class Message {
    public static final byte MSG_SENSOR = 0;

    static final int HEADER_SIZE = 1;

    byte msgType;

    public Message(byte msgType) {
        this.msgType = msgType;
    }

    public static Message parse(byte[] data) {
        Message msg = null;

        if (data.length < 1) {
            return msg;
        }

        switch (data[0]) {
            case MSG_SENSOR:
                msg = SensorMessage.parseMsg(data);
                break;
            default:
                break;
        }

        return msg;
    }

    public static class Builder {
        public static SensorMessage sensor(int sensorType, byte[] data) {
            return new SensorMessage(sensorType, data);
        }
        public static SensorMessage sensor(int sensorType, byte[] data, int count) {
            return new SensorMessage(sensorType, data, 0, count);
        }
        public static SensorMessage sensor(int sensorType, float[] data) {
            return new SensorMessage(sensorType, data);
        }
    }

    public abstract byte[] getBytes();

    void fillHeader(byte[] data) {
        data[0] = msgType;
    }
}
