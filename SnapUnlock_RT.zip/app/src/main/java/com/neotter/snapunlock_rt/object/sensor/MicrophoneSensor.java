package com.neotter.snapunlock_rt.object.sensor;

import java.io.File;

import com.neotter.snapunlock_rt.service.audio.AudioService;

public class MicrophoneSensor extends CommonSensor implements AudioService.OnAudioEventListener {
    private static final String NAME = "Microphone";

    private AudioService audioService;
    private File file;

    MicrophoneSensor() {
        audioService = new AudioService(this);
    }

    @Override
    public String getName() {
        return NAME;
    }

    @Override
    public int getMaxRate() {
        return audioService.getSampleRate();
    }

    @Override
    public int getType() {
        return TYPE_MICROPHONE;
    }

    @Override
    void openSensor() {
        audioService.startRecord();
    }

    @Override
    void closeSensor() {
        audioService.stopRecord();
    }

    @Override
    public void onStart() { }

    @Override
    public void onUpdate(byte[] data, int count) {
        report(data, count);
    }
}
