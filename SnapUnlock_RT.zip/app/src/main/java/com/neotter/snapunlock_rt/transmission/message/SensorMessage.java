package com.neotter.snapunlock_rt.transmission.message;


import com.neotter.snapunlock_rt.transmission.util.ByteUtil;

public class SensorMessage extends Message {
    public static final int TYPE_ACCELEROMETER = 1;
    public static final int TYPE_GYROSCOPE = 4;

    private int sensorType;
    private byte[] data;
    private int off;
    private int count;

    private byte[] bytes;

    static SensorMessage parseMsg(byte[] data) {
        if (data.length < HEADER_SIZE + 4) {
            return null;
        }

        return new SensorMessage(ByteUtil.byte2int(data, HEADER_SIZE), data, HEADER_SIZE + 4, data.length - (HEADER_SIZE + 4));
    }

    SensorMessage(int sensorType, float[] data) {
        super(MSG_SENSOR);


        this.sensorType = sensorType;
        this.off = 0;
        // float为4字节，为转换成Byte array做好准备
        this.data = new byte[data.length * 4];
        this.count = this.data.length;

        int pos = 0;
        for (int i = 0; i < data.length; ++i) {
            ByteUtil.float2byte(data[i], this.data, pos);
            pos += 4;
        }
        generateBytes();
    }

    SensorMessage(int sensorType, byte[] data) {
        this(sensorType, data, 0, data.length);
    }

    SensorMessage(int sensorType, byte[] data, int off, int count) {
        super(MSG_SENSOR);

        // off一直为零
        this.sensorType = sensorType;
        this.data = data;
        this.off = off;
        this.count = count;

        generateBytes();
    }

    public int getSensorType() {
        return sensorType;
    }

    public float[] getFloat() {
        float[] val = new float[(data.length - off) / 4];
        int pos = off;

        for (int i = 0; i < val.length; ++i) {
            val[i] = ByteUtil.byte2float(data, pos);
            pos += 4;
        }

        return val;
    }

    public short[] getShort() {
        short[] val = new short[(data.length - off) / 2];
        int pos = off;

        for (int i = 0; i < val.length; ++i) {
            val[i] = ByteUtil.byte2short(data, pos);
            pos += 2;
        }
        return val;
    }

    /**
     * [HEADER_SIZE][HEADER_SIZE + 4][...]
     * part2: sensor type (4byte)
     * part3: data
     */
    private void generateBytes() {

        // 而外的5个byte，第一位为msgType，然后四个byte用于存储int
        bytes = new byte[HEADER_SIZE + 4 + count];
        fillHeader(bytes);
        // 把sensorType（int）转换成byte然后保存到第HEADER_SIZE+1到+4中
        ByteUtil.int2byte(sensorType, bytes, HEADER_SIZE);
        // 把data copy到bytes中
        // bytes 结构： 第一位是MsgType，第二到五位是SensorType（int），后面3*8位是数据
        // count表示需要复制的长度，如果是普通sensor那么count就是sensor能获取的长度
        // 如果是microphone，调用onChange时会给出一个count
        System.arraycopy(data, off, bytes, HEADER_SIZE + 4, count);
    }

    @Override
    public byte[] getBytes() {
        return bytes;
    }
}
