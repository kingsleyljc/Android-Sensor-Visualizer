package com.neotter.snapunlock_rt.object.sensor;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

public class OrdinarySensor extends CommonSensor implements SensorEventListener {

    private static final int ONE_SECOND = 1000000;

    private Sensor sensor;
    private SensorManager sm;

    private String name;

    OrdinarySensor(Sensor sensor, SensorManager sm) {
        this.sensor = sensor;
        this.sm = sm;

        name = sensor.getName();
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public int getMaxRate() {
        if (sensor.getMinDelay() > 0) {
            return ONE_SECOND / sensor.getMinDelay();
        }
        return 0;
    }

    @Override
    public int getType() {
        return sensor.getType();
    }

    @Override
    void openSensor() {
        sm.registerListener(this, sensor, SensorManager.SENSOR_DELAY_FASTEST);
    }

    @Override
    void closeSensor() {
        sm.unregisterListener(this, sensor);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        report(event.values);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}
