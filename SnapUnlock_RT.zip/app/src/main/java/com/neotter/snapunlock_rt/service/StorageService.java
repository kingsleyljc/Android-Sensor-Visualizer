package com.neotter.snapunlock_rt.service;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.hardware.SensorManager;

import com.neotter.snapunlock_rt.object.sensor.CommonSensor;

import java.util.HashSet;
import java.util.Set;


public class StorageService {
    private static final String KEY_SENSOR_LIST = "sensorList";
    private static final String KEY_SEND_TO_SERVER = "sendToServer";
    private static final String KEY_SERVER_URL = "serverUrl";

    private static final String DEFAULT_SERVER_URL = "ws://192.168.1.100:7777/receiver";
    //private static final String DEFAULT_SERVER_URL = "ws://echo.websocket.org";

    private static StorageService mInstance;

    private SharedPreferences storage;
    private SensorManager sm;

    private Set<CommonSensor> sensorList;
    private Boolean sendToServer;
    private String serverUrl;

    public static StorageService getInstance() {
        if (mInstance == null) {
            mInstance = new StorageService();
        }
        return mInstance;
    }

    // 初始化
    public static void initialize(Application app) {
        StorageService storage = getInstance();
        storage.storage = app.getSharedPreferences("storage", Context.MODE_PRIVATE);
        storage.sm = (SensorManager) app.getSystemService(Context.SENSOR_SERVICE);
    }

    // SensorList的get和set
    public void setSensorList(Set<CommonSensor> sensorList) {
        if (this.sensorList == null) {
            this.sensorList = new HashSet<>();
        }

        this.sensorList.clear();
        Set<String> sensorTypeList = new HashSet<>();
        for (CommonSensor s : sensorList) {
            this.sensorList.add(s);
            sensorTypeList.add(String.valueOf(s.getType()));
        }

        SharedPreferences.Editor editor = storage.edit();
        editor.putStringSet(KEY_SENSOR_LIST, sensorTypeList);
        editor.commit();
    }

    public Set<CommonSensor> getSensorList() {
        if (sensorList == null) {
            sensorList = new HashSet<>();

            Set<String> sensorTypeList = storage.getStringSet(KEY_SENSOR_LIST, new HashSet<String>());
            for (String type : sensorTypeList) {
                int t = Integer.valueOf(type);
                sensorList.add(CommonSensor.getSensorByType(t, sm));
            }
        }

        return new HashSet<>(sensorList);
    }


    // sendToServer的get和set
    public boolean getSendToServer() {
        if (this.sendToServer == null) {
            this.sendToServer = storage.getBoolean(KEY_SEND_TO_SERVER, true);
        }

        return this.sendToServer;
    }

    public void setSendToServer(boolean sendToServer) {
        this.sendToServer = sendToServer;

        SharedPreferences.Editor editor = storage.edit();
        editor.putBoolean(KEY_SEND_TO_SERVER, sendToServer);
        editor.commit();
    }


    // serverUrl的get和set
    public String getServerUrL() {
        if (this.serverUrl == null) {
            this.serverUrl = storage.getString(KEY_SERVER_URL, DEFAULT_SERVER_URL);
        }

        return this.serverUrl;
    }

    public void setServerUrl(String serverUrl) {
        this.serverUrl = serverUrl;

        SharedPreferences.Editor editor = storage.edit();
        editor.putString(KEY_SERVER_URL, serverUrl);
        editor.commit();
    }
}
