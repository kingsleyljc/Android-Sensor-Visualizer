package com.neotter.snapunlock_rt;

import android.app.Activity;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.neotter.snapunlock_rt.adapter.SensorItemAdapter;
import com.neotter.snapunlock_rt.object.sensor.CommonSensor;
import com.neotter.snapunlock_rt.service.StorageService;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class SelectSensorActivity extends Activity implements SensorItemAdapter.OnToggleSensorListener, View.OnClickListener {

    private Button backBtn;
    private RecyclerView sensorListView;

    private StorageService storage;
    private Set<CommonSensor> selectedSensorList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_sensor);

        // 用于保存选择好的sensor
        storage = StorageService.getInstance();
        selectedSensorList = storage.getSensorList();

        backBtn = findViewById(R.id.backBtn);
        backBtn.setOnClickListener(this);

        // 初始化sensor view
        sensorListView = findViewById(R.id.sensorListView);
        initSensorListView();
    }

    private void initSensorListView() {
        sensorListView.setLayoutManager(new LinearLayoutManager(this));
        SensorItemAdapter adapter = new SensorItemAdapter(getAvailableSensorList(), selectedSensorList);
        adapter.setOnToggleSensorListener(this);
        sensorListView.setAdapter(adapter);
    }

    private List<CommonSensor> getAvailableSensorList() {
        SensorManager sm = (SensorManager) getSystemService(SENSOR_SERVICE);
        List<CommonSensor> sensorList = new ArrayList<>();

        sensorList.add(CommonSensor.getSensorByType(CommonSensor.TYPE_MICROPHONE, sm));
        for (Sensor sensor : sm.getSensorList(Sensor.TYPE_ALL)) {
            CommonSensor s = CommonSensor.getSensorByType(sensor.getType(), sm);
            if (s != null) {
                sensorList.add(s);
            }
        }

        return sensorList;
    }


    @Override
    public void onClick(View v) {
        finish();
    }

    @Override
    public void onChanged(CommonSensor sensor, boolean isChecked) {
        if (isChecked) {
            selectedSensorList.add(sensor);
        } else {
            selectedSensorList.remove(sensor);
        }
        Log.i("selectedSensorList","=================Start=================");
        for (CommonSensor selectedSensor : selectedSensorList) {
            Log.i("selectedSensorList",String.valueOf(selectedSensor.getType()));
        }
        Log.i("selectedSensorList","=================End=================");

        storage.setSensorList(selectedSensorList);
    }
}