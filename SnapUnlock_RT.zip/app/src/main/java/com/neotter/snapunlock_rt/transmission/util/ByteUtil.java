package com.neotter.snapunlock_rt.transmission.util;

public class ByteUtil {
    private static final int MASK = 0xFF;

    public static int byte2int(byte[] b, int off) {
        int val;
        val = b[off] & MASK;
        val += ((b[off + 1] & MASK) << 8);
        val += ((b[off + 2] & MASK) << 16);
        val += ((b[off + 3] & MASK) << 24);

        return val;
    }

    // 小端模式哦
    public static void int2byte(int val, byte[] b, int off) {

        b[off] = (byte) (val & MASK);
        b[off + 1] = (byte) ((val >> 8) & MASK);
        b[off + 2] = (byte) ((val >> 16) & MASK);
        b[off + 3] = (byte) ((val >> 24) & MASK);
    }

    public static short byte2short(byte[] b, int off) {
        short val;
        val = (short) (b[off] & MASK);
        val += (short) (b[off + 1] & MASK);

        return val;
    }

    public static float byte2float(byte[] b, int off) {
        return Float.intBitsToFloat(byte2int(b, off));
    }

    public static void float2byte(float val, byte[] b, int off) {
        int2byte(Float.floatToIntBits(val), b, off);
    }
}
