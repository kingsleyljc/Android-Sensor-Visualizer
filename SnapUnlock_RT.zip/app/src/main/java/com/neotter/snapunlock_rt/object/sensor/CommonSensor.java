package com.neotter.snapunlock_rt.object.sensor;

import android.hardware.Sensor;
import android.hardware.SensorManager;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

public abstract class CommonSensor {
    public static final int TYPE_DEVICE_CUSTOM_BASE = Sensor.TYPE_DEVICE_PRIVATE_BASE * 2;
    public static final int TYPE_MICROPHONE = TYPE_DEVICE_CUSTOM_BASE + 1;

    private static final HashMap<Integer, CommonSensor> sensorTypeMap = new HashMap<>();

    public static CommonSensor getSensorByType(int type, SensorManager sm) {
        CommonSensor sensor = sensorTypeMap.get(type);
        if (sensor == null) {
            if (type == TYPE_MICROPHONE) {
                sensor = new MicrophoneSensor();
                sensorTypeMap.put(type, sensor);
            } else {
                Sensor s = sm.getDefaultSensor(type);
                if (s != null) {
                    sensor = new OrdinarySensor(s, sm);
                    sensorTypeMap.put(type, sensor);
                }
            }
        }

        return sensor;
    }

    private Set<OnDataChangedListener> listeners;

    CommonSensor() {
        listeners = new HashSet<>();
    }

    public abstract String getName();
    public abstract int getType();
    public abstract int getMaxRate();
    abstract void openSensor();
    abstract void closeSensor();

    synchronized public void register(OnDataChangedListener listener) {
        if (!listeners.contains(listener)) {
            listeners.add(listener);

            if (listeners.size() == 1) {
                openSensor();
            }
        }
    }

    synchronized public void unregister(OnDataChangedListener listener) {
        if (listeners.contains(listener)) {
            listeners.remove(listener);

            if (listeners.size() == 0) {
                closeSensor();
            }
        }
    }

    synchronized void report(float[] val) {
        for (OnDataChangedListener listener : listeners) {
            if (listener != null) {
                listener.onChanged(this, val);
            }
        }
    }

    synchronized void report(byte[] data, int count) {
        for (OnDataChangedListener listener : listeners) {
            if (listener != null) {
                listener.onChanged(this, data, count);
            }
        }
    }
}
