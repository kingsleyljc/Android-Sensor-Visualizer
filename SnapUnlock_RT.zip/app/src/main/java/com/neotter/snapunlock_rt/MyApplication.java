package com.neotter.snapunlock_rt;

import android.app.Application;

import com.neotter.snapunlock_rt.service.StorageService;
import com.neotter.snapunlock_rt.transmission.SNWebSocketClient;

public class MyApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();

        // 读取上次保存的配置数据
        StorageService.initialize(this);
        SNWebSocketClient client = new SNWebSocketClient();


    }

}
