package com.neotter.snapunlock_rt;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;

import com.neotter.snapunlock_rt.service.StorageService;

public class ConfigActivity extends Activity {

    private Switch sendToServerSwitch;
    private EditText serverUrlEditText;

    private StorageService storageService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_config);

        storageService = StorageService.getInstance();

        serverUrlEditText = findViewById(R.id.serverUrlEditText);
        serverUrlEditText.setText(storageService.getServerUrL());

        boolean sendToServer = storageService.getSendToServer();
        if (sendToServer) {
            serverUrlEditText.setVisibility(View.VISIBLE);
        }

        sendToServerSwitch = findViewById(R.id.sendToServerSwitch);
        sendToServerSwitch.setChecked(sendToServer);
        sendToServerSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                serverUrlEditText.setVisibility(isChecked ? View.VISIBLE : View.GONE);
                storageService.setSendToServer(isChecked);
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        storageService.setServerUrl(serverUrlEditText.getText().toString());
    }
}