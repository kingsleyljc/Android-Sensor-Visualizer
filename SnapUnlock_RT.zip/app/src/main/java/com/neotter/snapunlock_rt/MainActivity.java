package com.neotter.snapunlock_rt;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;

import android.os.Looper;
import android.os.Message;

import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Toast;


import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.neotter.snapunlock_rt.object.sensor.CommonSensor;
import com.neotter.snapunlock_rt.object.sensor.OnDataChangedListener;
import com.neotter.snapunlock_rt.service.StorageService;
import com.neotter.snapunlock_rt.transmission.SNWebSocketClient;
import com.neotter.snapunlock_rt.transmission.WebSocketManager;
import com.neotter.snapunlock_rt.util.LoadingUtil;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.WebSocket;
import okio.ByteString;

public class MainActivity extends Activity implements View.OnClickListener, OnDataChangedListener {

    // 权限
    private static final String[] neededPermissions = new String[] {
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.RECORD_AUDIO,
    };
    private static final int REQUEST_PERMISSION_CODE = 321;
    private static final int MSG_SHOW_MSG = 0;
    private static final int MSG_RENDER = 1;
    private static final int MSG_SHOW_LOADING = 2;
    private static final int MSG_HIDE_LOADING = 3;

    private Button controlBtn;
    private Button selectSensorBtn;
    private Button configBtn;
    private Button exitBtn;

    private StorageService storage;
    private Handler mHandler;
    private LoadingUtil loadingUtil;


    private boolean isRecording;
    private Set<CommonSensor> registeredSensorList;
    private HashMap<CommonSensor, ArrayList<Float>[]> sensorDataMap;

    private StorageService storageService;
    OkHttpClient client;
    Request request;
    WebSocket webSocket;
    private boolean sendToServer;
    private String serverUrl;
    private boolean isCollectedData;
    private WebSocketManager wsManager;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // UI控制 //
        initHandler();

        controlBtn = findViewById(R.id.controlBtn);
        selectSensorBtn = findViewById(R.id.selectSensorBtn);
        configBtn = findViewById(R.id.configBtn);
        exitBtn = findViewById(R.id.exitBtn);

        controlBtn.setOnClickListener(this);
        selectSensorBtn.setOnClickListener(this);
        configBtn.setOnClickListener(this);
        exitBtn.setOnClickListener(this);

        storageService = StorageService.getInstance();
        storage = StorageService.getInstance();
        wsManager = WebSocketManager.getInstance();
        wsManager.init();
//        client = new OkHttpClient.Builder()
//                .pingInterval(10, TimeUnit.SECONDS)
//                .retryOnConnectionFailure(true)
//                .readTimeout(3, TimeUnit.SECONDS)
//                .writeTimeout(3,TimeUnit.SECONDS)
//                .connectTimeout(3,TimeUnit.SECONDS)
//                .build();

        isRecording = false;
        sensorDataMap = new HashMap<>();


        requestPermissions();
        keepScreenOn();

    }

    ////////////////////////////START:Handle处理UI操作////////////////////////////
    private void initHandler() {
        mHandler = new Handler(Looper.getMainLooper()) {
            @Override
            public void handleMessage(Message msg) {
                super.handleMessage(msg);

                switch (msg.what) {
                    case MSG_SHOW_MSG:
                        Toast.makeText(MainActivity.this, msg.arg1, Toast.LENGTH_SHORT).show();
                        break;
                    case MSG_RENDER:
                        render(); break;
                    case MSG_SHOW_LOADING:
                        //showLoading(); break;
                    case MSG_HIDE_LOADING:
                        //hideLoading(); break;
                    default:
                        break;
                }
            }
        };
    }

    private void render() {
        if (isRecording) {
            controlBtn.setText(R.string.btn_stop);
        } else {
            controlBtn.setText(R.string.btn_record);
        }

        selectSensorBtn.setEnabled(!isRecording);
    }

    private void showMsg(int msg) {
        Message m = new Message();
        m.what = MSG_SHOW_MSG;
        m.arg1 = msg;
        mHandler.sendMessage(m);
    }

    private void updateUI() {
        mHandler.sendEmptyMessage(MSG_RENDER);
    }

    ////////////////////////////END:UI控制////////////////////////////


    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.controlBtn:
                control(); break;
            case R.id.selectSensorBtn:
                selectSensor(); break;
            case R.id.configBtn:
                config(); break;
            case R.id.exitBtn:
                System.exit(0);
            default:
                break;
        }
    }

    private void control() {
        isRecording = !isRecording;
        if (isRecording) {
            isCollectedData = false;
            clearData();
            record();
        } else {
            stop();
        }
    }

    private void record() {

        // Check sensor list is not empty
        registeredSensorList = storage.getSensorList();
        if (registeredSensorList.size() == 0) {
            showMsg(R.string.hint_no_sensor_selected);
            isRecording = false;
            return;
        }

        sendToServer = storageService.getSendToServer();
        serverUrl = storageService.getServerUrL();
        if (sendToServer){
//            try{
//                request = new Request.Builder().url(serverUrl).build();
//            } catch (Exception e){
//                e.printStackTrace();
//                showMsg(R.string.hint_failed_to_start_server);
//                return;
//            }
            if(!wsManager.setWSURL(serverUrl)){
                return;
            }
            updateUI();
            // 在这一步建立连接
//            webSocket  = client.newWebSocket(request,new SNWebSocketClient());
            wsManager.connect();
        }

        for (CommonSensor sensor : registeredSensorList) {
//            if (sensor.getType() == CommonSensor.TYPE_MICROPHONE) {
//                try {
//                    os = new FileOutputStream(audioFile);
//                } catch (FileNotFoundException e) {
//                    e.printStackTrace();
//                }
//            }
            // 注册到需要采集的sensor中
            sensor.register((OnDataChangedListener) this);
        }
    }

    private void clearData() {
        isCollectedData = false;
        for (CommonSensor sensor : sensorDataMap.keySet()) {
            ArrayList[] data = sensorDataMap.get(sensor);
            for (ArrayList row : data) {
                row.clear();
            }
        }
    }

    // Stop只会停止监视sensor，这时数据并不会保存
    // 并且用新开的线程传递UI操作的信息给主线程
    private void stop() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                for (CommonSensor sensor : registeredSensorList){
                    sensor.unregister(MainActivity.this);
                }
                clearData();
//                if (client != null){
//                    client.connectionPool().evictAll();
//                }
                wsManager.close();
                mHandler.sendEmptyMessage(MSG_HIDE_LOADING);
                updateUI();
            }
        }).start();
    }

    private void selectSensor() {
        startActivity(new Intent(this, SelectSensorActivity.class));
    }

    private void config() {
        startActivity(new Intent(this, ConfigActivity.class));
    }

    private void keepScreenOn() {
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }
    private void cancelKeepingScreenOn() {
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    // 获取传感器数据
    private byte[] getSensorData(CommonSensor sensor) {
        StringBuilder sb = new StringBuilder();
        ArrayList<Float>[] data = sensorDataMap.get(sensor);
        if (data != null) {
            for (int r = 0; r < data.length; ++r) {
                sb.append("axis-");
                sb.append(r + 1);
                ArrayList<Float> row = data[r];
                for (int i = 0, len = row.size(); i < len; ++i) {
                    sb.append(',');
                    sb.append(row.get(i));
                }
                sb.append('\n');
            }
        }
        return sb.toString().getBytes();
    }

    // 非麦克风传感器的数据
    @Override
    public void onChanged(CommonSensor sensor, float[] value) {
        if (isRecording) {
            isCollectedData = true;

            if (sendToServer) {
                ArrayList[] data = sensorDataMap.get(sensor);
                if (data == null) {
                    data = new ArrayList[value.length];
                    for (int i = 0; i < data.length; ++i) {
                        data[i] = new ArrayList<Float>();
                    }
                    sensorDataMap.put(sensor, data);
                }

                for (int i = 0; i < value.length; ++i) {
                    data[i].add(value[i]);
                }
            }

            byte[] bytes = com.neotter.snapunlock_rt.transmission.message.Message.Builder.sensor(sensor.getType(), value).getBytes();
            //Log.i("nonMicrophone",String.valueOf(bytes.length));
            //Log.i("nonMicrophone","X:"+String.valueOf(value[0])+" Y:"+String.valueOf(value[1])+" Z:"+String.valueOf(value[0]));
            wsManager.sendMessage(ByteString.of(bytes,0,bytes.length));
        }
    }

    // 麦克风传感器的数据
    @Override
    public void onChanged(CommonSensor sensor, byte[] data, int count) {
        if (isRecording) {
            isCollectedData = true;
            byte[] bytes = com.neotter.snapunlock_rt.transmission.message.Message.Builder.sensor(sensor.getType(), data, count).getBytes();
            wsManager.sendMessage(ByteString.of(bytes,0,bytes.length));
        }
    }

    // 剩余的生命周期
    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (isRecording) {
            stop();
        }
        WebSocketManager.release();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPostResume() {
        super.onPostResume();
    }

    /**
     * 请求权限授权
     * @return 全部授权时返回 true
     */
    private boolean requestPermissions() {
        ArrayList<String> unauthorizedPermissions = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            for (String permission : neededPermissions) {
                if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                    unauthorizedPermissions.add(permission);
                }
            }

            if (unauthorizedPermissions.size() > 0) {
                ActivityCompat.requestPermissions(this, unauthorizedPermissions.toArray(new String[0]), REQUEST_PERMISSION_CODE);
                return false;
            }
        }

        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQUEST_PERMISSION_CODE) {
            boolean allPermissionsGranted = true;
            for (int i = 0; i < grantResults.length; ++i) {
                if (grantResults[i] != PackageManager.PERMISSION_GRANTED) {
                    allPermissionsGranted = false;
                    break;
                }
            }

            if (!allPermissionsGranted) {
                showMsg(R.string.hint_grant_all_permission);
            }
        }
    }
}
