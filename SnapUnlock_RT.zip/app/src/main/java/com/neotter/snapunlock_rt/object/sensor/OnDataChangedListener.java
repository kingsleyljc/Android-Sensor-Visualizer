package com.neotter.snapunlock_rt.object.sensor;

public interface OnDataChangedListener {
    void onChanged(CommonSensor sensor, float[] value);
    void onChanged(CommonSensor sensor, byte[] data, int count);
}
